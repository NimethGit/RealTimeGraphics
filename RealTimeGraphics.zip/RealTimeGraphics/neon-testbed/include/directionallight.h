// directionallight.h

#ifndef  DIRECTIONALLIGHT_H_INCLUDED
#define  DIRECTIONALLIGHT_H_INCLUDED

#include <neon_core.h>
#include <neon_opengl.h>
#include "neon_graphics.h"

namespace neon
{
	struct directionallight
	{

		directionallight();

		void changeAmbientColor(glm::vec3 newColor);
		void changeDiffuseColor(glm::vec3 newColor);
		void changeSpecularColor(glm::vec3 newColor);
		void changeAmbientIntenstity(float newIntensity);
		void changeDiffuseIntenstity(float newIntensity);
		void changeSpecularIntenstity(float newIntensity);
		void changeDirection(glm::vec3 newDirection);

		glm::vec3 direction_;
		glm::vec3 ambient_color_;
		glm::vec3 diffuse_color_;
		glm::vec3 specular_color_;

		float ambient_intensity_;
		float diffuse_intensity_;
		float specular_intensity_;

	};
}
#endif //  !DIRECTIONALLIGHT_H_INCLUDED