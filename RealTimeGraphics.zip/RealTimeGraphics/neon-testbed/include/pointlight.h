// pointlight.h

#ifndef  POINTLIGHT_H_INCLUDED
#define  POINTLIGHT_H_INCLUDED

#include <neon_core.h>
#include <neon_opengl.h>
#include "neon_graphics.h"

namespace neon
{
	struct pointlight
	{
		struct vertex
		{
			glm::vec3 position_;
			glm::vec2 texcoord_;
		};

		pointlight();
		void render(glm::mat4 projectionMatrix, glm::mat4 viewMatrix);
		void setPosition(glm::vec3 newPosition);
		void changeAttenuation(float constant, float linear, float quadratic);
		//void changeAmbientColor(glm::vec3 newColor);
		//void changeDiffuseColor(glm::vec3 newColor);
		//void changeSpecularColor(glm::vec3 newColor);

		void changeAmbientColor(glm::vec3 newColor);
		void changeDiffuseColor(glm::vec3 newColor);
		void changeSpecularColor(glm::vec3 newColor);
		void changeAmbientIntenstity(float newIntensity);
		void changeDiffuseIntenstity(float newIntensity);
		void changeSpecularIntenstity(float newIntensity);

		void translate(glm::mat4 startingPoint, glm::vec3 translation);
		void rotate(glm::mat4 origin, float rotationAmount, glm::vec3 axis);

		glm::mat4 world;
		glm::vec3 position_;

		glm::vec3 ambient_color_;
		glm::vec3 diffuse_color_;
		glm::vec3 specular_color_;
		float ambient_intensity_;
		float diffuse_intensity_;
		float specular_intensity_;

		//Attenuation
		//(To reduce the intensity of light, over the distance a light ray travels, is generally called attenuation.) 
		//Read: http://wiki.ogre3d.org/tiki-index.php?page=-Point+Light+Attenuation 
		//Read: https://learnopengl.com/Lighting/Light-casters
		float constant_ = 1.0f;
		float linear_ = 0.09f;
		float quadratic_ = 0.032f;

		//STUFF TO HELP VISUALIZE THE LIGHT SOURCE
		float radius_ = 0.3f;

		vertex_buffer vbo_;
		index_buffer ibo_;
		vertex_format format_;
		texture texture_;
		shader_program program_;
		sampler_state sampler_;
		int index_count_ = 0;
	};
}


#endif //  !POINTLIGHT_H_INCLUDED