// neon_testbed.h

#ifndef NEON_TESTBED_H_INCLUDED
#define NEON_TESTBED_H_INCLUDED

#include <neon_core.h>
#include <neon_opengl.h>

#include "neon_graphics.h"
#include "neon_model.h"
#include "neon_framebuffer.h"

#include "cube.h"
#include "sphere.h"
#include "sphereDirectionalLight.h"
#include "pointlight.h"
#include "directionallight.h"
#include "quadInversionEffect.h"
#include "quadDepthMap.h"
#include "plane.h"

namespace neon
{
	struct vertex
	{
		float x_;
		float y_;
		float z_;
		uint32 color_;
		float u;
		float v;
	};

	struct testbed : application
	{
		testbed();
		virtual bool enter() final; // final keyword: when we derive some class from testbed we don't need to implement enter again.
		virtual void exit() final;
		virtual bool tick(const time& dt) final;

		void updateSettings(const time& dt);
		void updateCameraText(const time& dt, fps_camera& camera);
		void updateLightText();
		void updateKeybindingText();
		void updateObjectTransforms(const time& dt);

		bitmap_font font_;
		fps_camera camera_;
		fps_camera_controller controller_;
		skybox skybox_;
		framebuffer framebuffer_;
		framebuffer framebuffer2_;

		cube cube_;
		cube cube2_;
		sphereDirectionalLight sphereDL_;
		sphereDirectionalLight sphereDL2_;
		plane plane_;
		directionallight directionallight_;

		sphere sphere_;
		sphere sphere2_;
		pointlight pointlight_;

		quadDepthMap depth_quad_;
		quadInversionEffect inversion_quad_;

		bool displayKeybinding_ = true;
		bool displayCameraSettings_ = true;
		bool displayLightSettings_ = true;
		bool usePostProcessEffect_ = false;

		float ambientRed_ = 0.5f;
		float ambientGreen_ = 0.6f;
		float ambientBlue_ = 0.8f;		
		float diffuseRed_ = 0.15f;
		float diffuseGreen_ = 0.26f;
		float diffuseBlue_ = 0.35f;
		float specularRed_ = 0.15f;
		float specularGreen_ = 0.26f;
		float specularBlue_ = 0.35f;
		float ambientIntensity_ = 0.2f;
		float diffuseIntensity_ = 0.2f;
		float specularIntensity_ = 0.4f;
		float xDirection_ = 0.0f;
		float yDirection_ = -1.0f;
		float zDirection_ = 0.0f;
		
		float orbit_ = 0.0f;
	};
} // !neon

#endif // !NEON_TESTBED_H_INCLUDED
