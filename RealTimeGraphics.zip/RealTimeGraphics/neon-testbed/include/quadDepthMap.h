#ifndef  QUADDEPTHMAP_H_INCLUDED
#define  QUADDEPTHMAP_H_INCLUDED

#include <neon_core.h>
#include <neon_opengl.h>
#include "neon_graphics.h"

namespace neon
{
	struct quadDepthMap
	{
		struct vertex
		{
			glm::vec2 position_;
			glm::vec2 texcoord_;
		};

		quadDepthMap();

		void render();

		vertex_buffer vbo_;
		index_buffer ibo_;
		vertex_format format_;
		//texture texture_; //DON'T NEED THIS?
		shader_program program_;
		sampler_state sampler_;
		int index_count_ = 0;
	};
}

#endif //  !QUADDEPTHMAP_H_INCLUDED