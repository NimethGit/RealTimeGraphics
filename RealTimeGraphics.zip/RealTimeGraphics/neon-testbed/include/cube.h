// Cube.h

#ifndef  CUBE_H_INCLUDED
#define  CUBE_H_INCLUDED

#include <neon_core.h>
#include <neon_opengl.h>
#include "neon_graphics.h"

#include "directionallight.h"

namespace neon
{
	struct cube
	{
		struct vertex
		{
			glm::vec3 position_;
			glm::vec2 texcoord_;
			glm::vec3 normal_;
		};

		cube();

		void renderDepth(glm::mat4 lightMVP);
		void render(glm::mat4 projectionMatrix, glm::mat4 viewMatrix, glm::vec3 cameraPosition, directionallight &dl, glm::mat4 lightMVP);

		void setPosition(glm::vec3 newPosition);
		void translate(glm::mat4 startingPoint, glm::vec3 translation);
		void rotate(glm::mat4 origin, float rotationAmount, glm::vec3 axis);


		float scale_ = 1.0f;
		glm::mat4 world;

		vertex_buffer vbo_;
		index_buffer ibo_;
		vertex_format format_;
		texture texture_;
		shader_program program_;
		shader_program program_depth_;
		sampler_state sampler_;
		int index_count_ = 0;
	};

}
#endif //  !CUBE_H_INCLUDED
