#include "sphereDirectionalLight.h"

neon::sphereDirectionalLight::sphereDirectionalLight()
{
	world = glm::mat4(1.0f);

	dynamic_array<vertex> vertices;
	dynamic_array<uint32> indices;

	// Settings for calculating the vertices
	const int SECTORCOUNT_ = 40;                        // longitude, number of slices
	const int STACKCOUNT_ = 40;                         // latitude, number of stacks
	float sectorStep_ = 2.0f * PI / SECTORCOUNT_;
	float stackStep_ = PI / STACKCOUNT_;

	//Populating the UV grid with the vertices
	for (int i = 0; i < STACKCOUNT_ + 1; ++i)
	{
		float stackAngle_ = PI / 2 - i * stackStep_;
		float xy = radius_ * cosf(stackAngle_);
		float z = radius_ * sinf(stackAngle_);

		for (int j = 0; j < SECTORCOUNT_ + 1; ++j)
		{
			float sectorAngle_ = j * sectorStep_;

			float x = xy * cosf(sectorAngle_);
			float y = xy * sinf(sectorAngle_);
			vertex vert = { glm::vec3(x, z, y), glm::vec2((float)j / SECTORCOUNT_, (float)i / STACKCOUNT_), glm::normalize(glm::vec3(x, z, y)) };
			vertices.push_back(vert);
		}
	}

	//SORT THE VERTICES
	for (int i = 0; i < STACKCOUNT_; i++) //Latitude
	{
		for (int j = 0; j < SECTORCOUNT_; j++) //Longitude
		{
			int width = SECTORCOUNT_ + 1;
			int index = (i * width) + j;

			indices.push_back(index);
			indices.push_back(index + width + 1);
			indices.push_back(index + 1);

			indices.push_back(index + width + 1);
			indices.push_back(index);
			indices.push_back(index + width);
		}
	}
	index_count_ = (int)indices.size();


	if (!ibo_.create(index_count_ * sizeof(uint32), GL_UNSIGNED_INT, indices.data()))
	{
		return;
	}

	if (!vbo_.create(sizeof(vertex) * (int)vertices.size(), vertices.data()))
	{
		return;
	}

	if (!program_.create("assets/shadow/shadow_vertex_shader.txt", "assets/shadow/shadow_fragment_shader.txt"))
	{
		return;
	}

	if (!program_depth_.create("assets/shadow/DepthMapGeneration_vertex_shader.txt", "assets/shadow/DepthMapGeneration_fragment_shader.txt"))
	{
		return;
	}

	format_.add_attribute(0, 3, GL_FLOAT, false);
	format_.add_attribute(1, 2, GL_FLOAT, true);
	format_.add_attribute(2, 3, GL_FLOAT, false);

	if (!texture_.create("assets/sphere/sphere.png"))
	{
		return;
	}

	if (!sampler_.create(GL_NEAREST, GL_CLAMP_TO_EDGE, GL_CLAMP_TO_EDGE))
	{
		return;
	}
}
void neon::sphereDirectionalLight::render(glm::mat4 projectionMatrix, glm::mat4 viewMatrix, glm::vec3 cameraPosition, directionallight& dl, glm::mat4 lightMVP)
{
	program_.bind();

	program_.set_uniform_texture("diffuse", 0);
	program_.set_uniform_texture("depth_map", 1);

	program_.set_uniform_mat4("projection", projectionMatrix);
	program_.set_uniform_mat4("view", viewMatrix);
	program_.set_uniform_mat4("world", world);
	program_.set_uniform_mat4("lightMVP", lightMVP);

	program_.set_uniform_vec3("ambient_light_color", dl.ambient_color_);
	program_.set_uniform_vec3("diffuse_light_color", dl.diffuse_color_);
	program_.set_uniform_vec3("specular_light_color", dl.specular_color_);
	program_.set_uniform_float("ambient_intensity", dl.ambient_intensity_);
	program_.set_uniform_float("diffuse_intensity", dl.diffuse_intensity_);
	program_.set_uniform_float("specular_intensity", dl.specular_intensity_);

	program_.set_uniform_vec3("light_direction", dl.direction_);
	program_.set_uniform_vec3("camera_pos", cameraPosition);

	vbo_.bind();
	format_.bind();
	ibo_.bind();

	texture_.bind(0);
	sampler_.bind(0); //Binding this sampler to the unit 0
	sampler_.bind(1);

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);
	glCullFace(GL_BACK);
	glFrontFace(GL_CW);
	ibo_.render(GL_TRIANGLES, 0, index_count_);
}

void neon::sphereDirectionalLight::renderDepth(glm::mat4 lightMVP)
{
	program_depth_.bind();
	program_depth_.set_uniform_mat4("lightMVP", lightMVP);
	program_depth_.set_uniform_mat4("world", world);

	vbo_.bind();
	format_.bind();
	ibo_.bind();

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);
	glCullFace(GL_FRONT);	//ADDED
	//glCullFace(GL_BACK); //COMMENTED OUT
	glFrontFace(GL_CW);
	ibo_.render(GL_TRIANGLES, 0, index_count_);
	glCullFace(GL_BACK); //ADDED
}

void neon::sphereDirectionalLight::setPosition(glm::vec3 newPosition)
{
	world[3][0] = newPosition.x;
	world[3][1] = newPosition.y;
	world[3][2] = newPosition.z;
}

void neon::sphereDirectionalLight::translate(glm::mat4 startingPoint, glm::vec3 translation)
{
	world = glm::translate(startingPoint, translation);
}

void neon::sphereDirectionalLight::rotate(glm::mat4 origin, float rotationAmount, glm::vec3 axis)
{
	world = glm::rotate(origin, rotationAmount, axis);
}
