#include "plane.h"

neon::plane::plane()
{
	world = glm::mat4(1.0f);

	dynamic_array<vertex> vertices;
	dynamic_array<uint32> indices;

	float scale = 10.0f;
	vertex topLeft =  { glm::vec3(-1.0f * scale, 0.0f, -1.0f * scale), glm::vec2(0.0f, 1.0f), glm::vec3(0.0f, 1.0f, 0.0f) };
	vertex topRight = { glm::vec3( 1.0f * scale, 0.0f, -1.0f * scale), glm::vec2(1.0f, 1.0f), glm::vec3(0.0f, 1.0f, 0.0f) };
	vertex botRight = { glm::vec3( 1.0f * scale, 0.0f,  1.0f * scale), glm::vec2(1.0f, 0.0f), glm::vec3(0.0f, 1.0f, 0.0f) };
	vertex botLeft =  { glm::vec3(-1.0f * scale, 0.0f,  1.0f * scale), glm::vec2(0.0f, 0.0f), glm::vec3(0.0f, 1.0f, 0.0f) };

	vertices.push_back(topLeft);
	vertices.push_back(topRight);
	vertices.push_back(botRight);
	vertices.push_back(botLeft);

	indices.push_back(0);
	indices.push_back(1);
	indices.push_back(2);
	indices.push_back(2);
	indices.push_back(3);
	indices.push_back(0);

	index_count_ = (int)indices.size();

	if (!ibo_.create(index_count_ * sizeof(uint32), GL_UNSIGNED_INT, indices.data()))
	{
		return;
	}

	if (!vbo_.create(sizeof(vertex) * (int)vertices.size(), vertices.data()))
	{
		return;
	}

	if (!program_.create("assets/shadow/shadow_vertex_shader.txt", "assets/shadow/shadow_fragment_shader.txt"))
	{
		return;
	}

	if (!program_depth_.create("assets/shadow/DepthMapGeneration_vertex_shader.txt", "assets/shadow/DepthMapGeneration_fragment_shader.txt"))
	{
		return;
	}

	format_.add_attribute(0, 3, GL_FLOAT, false);
	format_.add_attribute(1, 2, GL_FLOAT, true);
	format_.add_attribute(2, 3, GL_FLOAT, false);

	if (!texture_.create("assets/plane/plane.jpg"))
	{
		return;
	}

	if (!sampler_.create(GL_NEAREST, GL_CLAMP_TO_EDGE, GL_CLAMP_TO_EDGE))
	{
		return;
	}

}

void neon::plane::renderDepth(glm::mat4 lightMVP)
{
	program_depth_.bind();
	program_depth_.set_uniform_mat4("lightMVP", lightMVP);
	program_depth_.set_uniform_mat4("world", world);

	vbo_.bind();
	format_.bind();
	ibo_.bind();

	//texture_.bind();	//NOT SURE IF WE NEED TO BIND THE TEXTURE OR SAMPLER HERE
	//sampler_.bind();

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);
	glCullFace(GL_FRONT);	//ADDED
	//glCullFace(GL_BACK); //COMMENTED OUT
	glFrontFace(GL_CW);
	ibo_.render(GL_TRIANGLES, 0, index_count_);
	glCullFace(GL_BACK); //ADDED
}

void neon::plane::setPosition(glm::vec3 newPosition)
{
	world[3][0] = newPosition.x;
	world[3][1] = newPosition.y;
	world[3][2] = newPosition.z;
}

void neon::plane::render(glm::mat4 projectionMatrix, glm::mat4 viewMatrix, glm::vec3 cameraPosition, directionallight& dl, glm::mat4 lightMVP)
{
	program_.bind();

	program_.set_uniform_texture("diffuse", 0);
	program_.set_uniform_texture("depth_map", 1);

	program_.set_uniform_mat4("projection", projectionMatrix);
	program_.set_uniform_mat4("view", viewMatrix);
	program_.set_uniform_mat4("world", world);
	program_.set_uniform_mat4("lightMVP", lightMVP);

	program_.set_uniform_vec3("ambient_light_color", dl.ambient_color_);
	program_.set_uniform_vec3("diffuse_light_color", dl.diffuse_color_);
	program_.set_uniform_vec3("specular_light_color", dl.specular_color_);
	program_.set_uniform_float("ambient_intensity", dl.ambient_intensity_);
	program_.set_uniform_float("diffuse_intensity", dl.diffuse_intensity_);
	program_.set_uniform_float("specular_intensity", dl.specular_intensity_);

	program_.set_uniform_vec3("light_direction", dl.direction_);
	program_.set_uniform_vec3("camera_pos", cameraPosition);

	vbo_.bind();
	format_.bind();
	ibo_.bind();

	texture_.bind(0);
	sampler_.bind(0); //Binding this sampler to the unit 0
	sampler_.bind(1);

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);
	glCullFace(GL_BACK);
	glFrontFace(GL_CW);
	ibo_.render(GL_TRIANGLES, 0, index_count_);
}
