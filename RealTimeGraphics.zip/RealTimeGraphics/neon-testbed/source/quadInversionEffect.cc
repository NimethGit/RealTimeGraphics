#include "quadInversionEffect.h"

neon::quadInversionEffect::quadInversionEffect()
{
	dynamic_array<vertex> vertices;
	dynamic_array<uint32> indices;

	vertex topLeft = { glm::vec2(-1.0f, 1.0f), glm::vec2(0.0f, 1.0f) };
	vertex topRight = { glm::vec2(1.0f, 1.0f), glm::vec2(1.0f, 1.0f) };
	vertex botLeft = { glm::vec2(-1.0f, -1.0f), glm::vec2(0.0f, 0.0f) };
	vertex botRight = { glm::vec2(1.0f, -1.0f), glm::vec2(1.0f, 0.0f) };

	vertices.push_back(topLeft);
	vertices.push_back(topRight);
	vertices.push_back(botRight);
	vertices.push_back(botLeft);

	indices.push_back(0);
	indices.push_back(1);
	indices.push_back(2);
	indices.push_back(2);
	indices.push_back(3);
	indices.push_back(0);

	index_count_ = (int)indices.size();

	if (!ibo_.create(index_count_ * sizeof(uint32), GL_UNSIGNED_INT, indices.data()))
	{
		return;
	}

	if (!vbo_.create(sizeof(vertex) * (int)vertices.size(), vertices.data()))
	{
		return;
	}

	if (!program_.create("assets/effects/invert_vertex_shader.txt", "assets/effects/invert_fragment_shader.txt"))
	{
		return;
	}

	format_.add_attribute(0, 2, GL_FLOAT, false);
	format_.add_attribute(1, 2, GL_FLOAT, true);

	//I THINK I SHOULD CREATE THE TEXTURE IN A DIFFERENT WAY HERE
	/*if (!texture_.create("assets/cube/cube.png"))
	{
		return;
	}*/

	if (!sampler_.create(GL_NEAREST, GL_CLAMP_TO_EDGE, GL_CLAMP_TO_EDGE))
	{
		return;
	}

}

void neon::quadInversionEffect::render()
{
	program_.bind();

	vbo_.bind();
	format_.bind();
	ibo_.bind();

	sampler_.bind();

	glDisable(GL_DEPTH_TEST);
	//glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);
	//glDisable(GL_CULL_FACE);
	glCullFace(GL_BACK);
	glFrontFace(GL_CW);
	ibo_.render(GL_TRIANGLES, 0, index_count_);
}
