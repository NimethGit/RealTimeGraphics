// neon_testbed.cc

#include "neon_testbed.h"
#include <cassert>

namespace neon
{
	// note: application factory
	application* application::create(int& width, int& height, string& title) {
		width = 1280; height = 720;
		title = "neon-testbed";
		return new testbed;
	}

	namespace opengl
	{
		GLuint create_shader(GLenum type, const char* source)
		{
			GLuint id = glCreateShader(type);
			glShaderSource(id, 1, &source, nullptr);
			glCompileShader(id);

			return id;
		}
		// vid: vertex shader id					fid: fragment shader id
		GLuint create_program(GLuint vid, GLuint fid)
		{
			GLuint id = glCreateProgram();
			glAttachShader(id, vid);
			glAttachShader(id, fid);
			glLinkProgram(id);

			GLint status = 0;	// check the shaders if there are any compilation errors.
			glGetProgramiv(id, GL_LINK_STATUS, &status);	// check if the two shaders linked.
			if (status == GL_FALSE)
			{
				char vsh_err[1024] = {};
				char fsh_err[1024] = {};
				char sh_err[1024] = {};

				glGetShaderInfoLog(vid, sizeof(vsh_err), nullptr, vsh_err);
				glGetShaderInfoLog(fid, sizeof(fsh_err), nullptr, fsh_err);
				glGetShaderInfoLog(id, sizeof(sh_err), nullptr, sh_err);

				assert(false);

				return 0;
			}

			glDeleteShader(vid);
			glDeleteShader(fid);

			return id;
		}
	} // !opengl

	// note: derived application class
	testbed::testbed()
		: controller_(camera_, keyboard_, mouse_)
	{
	}

	bool testbed::enter()
	{
		GLuint vao = 0;	// vao: vertex array object
		glGenVertexArrays(1, &vao);
		glBindVertexArray(vao);

		//Setting up the camera starting position
		camera_.position_ = { -20.0f, 16.0f, 0.0f };
		camera_.pitch_ = -0.6f;
		camera_.yaw_ = -1.6f;


		// note: uniforms
		glm::mat4 projection = glm::perspective(glm::radians(45.0f), 16.0f / 9.0f, 0.5f, 100.0f);


		GLenum error = glGetError();
		if (error != GL_NO_ERROR)
		{
			// ...
		}

		if (!font_.create())
		{
			return false;
		}

		if (!skybox_.create())
		{
			return false;
		}

		framebuffer_format formats[] = { FRAMEBUFFER_FORMAT_D32 };
		if (!framebuffer_.create(2048, 2048, _countof(formats), formats, FRAMEBUFFER_FORMAT_NONE))
		{
			return false;
		}

		framebuffer_format formats2[] = { FRAMEBUFFER_FORMAT_RGBA8, FRAMEBUFFER_FORMAT_D32 };
		if (!framebuffer2_.create(1280, 720, _countof(formats2), formats2, FRAMEBUFFER_FORMAT_NONE))
		{
			return false;
		}

		camera_.set_perspective(glm::radians(45.0f), 16.0f / 9.0f, 0.5f, 100.0f);
		pointlight_.setPosition(glm::vec3(15.0f, 2.0f, 0.0f));

		return true;
	}

	void testbed::exit()
	{
	}

	bool testbed::tick(const time& dt)
	{
		if (keyboard_.is_pressed(KEYCODE_ESCAPE))
		{
			return false;
		}

		controller_.update(dt);
		updateSettings(dt);
		
		glm::vec3 cameraOffset = { 0.0f, 3.0f, 0.0f };
		glm::vec3 right = glm::vec3(1.0f, 0.0f, 0.0f); 
		glm::vec3 up = glm::normalize(glm::cross(directionallight_.direction_, right));
		glm::mat4 lightProj = glm::ortho(-30.0f, 30.0f, -30.0f, 30.0f, 0.1f, 25.0f);
		glm::mat4 lightView = glm::lookAt(-directionallight_.direction_ * 10.0f + cameraOffset, glm::vec3(0.0f,0.0f,0.0f), up);
		glm::mat4 lightMVP = lightProj * lightView;

		framebuffer_.bind();
		glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		updateKeybindingText();
		if(displayCameraSettings_)
		{
			updateCameraText(dt, camera_);
		}
		if (displayLightSettings_)
		{
			updateLightText();
		}

		updateObjectTransforms(dt);

		//FIRST PASS -> POPULATE THE DEPTH MAP
		cube_.renderDepth(lightMVP);
		cube2_.renderDepth(lightMVP);
		plane_.renderDepth(lightMVP);
		sphereDL_.renderDepth(lightMVP);
		sphereDL2_.renderDepth(lightMVP);

		sphere_.renderDepth(lightMVP);
		sphere2_.renderDepth(lightMVP);

		framebuffer::unbind(1280, 720);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

#if 1
		//SECOND PASS -> RENDER THE SCENE NORMALLY WITH DEPTH MAP IN CONSIDERATION
		framebuffer2_.bind();
		glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
		glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

		skybox_.render(camera_);
		framebuffer_.bind_as_texture(0, 1); //BIND INDEX 0 IN THE FBO TO THE 1 IN THE FRAGMENT SHADER (IT GETS MAPPED BY STATE MACHINE)
		plane_.render(camera_.projection_, camera_.view_, camera_.position_, directionallight_, lightMVP);
		cube_.render(camera_.projection_, camera_.view_, camera_.position_, directionallight_, lightMVP);
		cube2_.render(camera_.projection_, camera_.view_, camera_.position_, directionallight_, lightMVP);
		sphereDL_.render(camera_.projection_, camera_.view_, camera_.position_, directionallight_, lightMVP);
		sphereDL2_.render(camera_.projection_, camera_.view_, camera_.position_, directionallight_, lightMVP);
#endif

#if 1
		//THE SPHERES WILL CAST SHADOWS, BUT THEY ARE NOT AFFECTED BY THE DIRECTIONAL LIGHT. THEY ARE AFFECTED BY THE POINTLIGHT
		pointlight_.render(camera_.projection_, camera_.view_);
		sphere_.render(camera_.projection_, camera_.view_, camera_.position_, pointlight_);
		sphere2_.render(camera_.projection_, camera_.view_, camera_.position_, pointlight_);

#endif 

		//THIRD PASS -> POST PROCESSING ( EFFECTS )
		if (!usePostProcessEffect_)
		{
			//RENDER UI		
			glEnable(GL_DEPTH_TEST);
			glEnable(GL_CULL_FACE);
			glCullFace(GL_BACK);
			glFrontFace(GL_CW);

			font_.flush();

			framebuffer::unbind(1280, 720);
			framebuffer2_.blit(0, 0, 1280, 720); //Where we want it to render and width, height
		}
		else
		{
			framebuffer::unbind(1280, 720);
			glClearColor(0.0f, 0.0f, 0.0f, 0.0f);
			glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
			framebuffer2_.bind_as_texture(0,0);
			inversion_quad_.render();	
			
			//RENDER UI		
			glEnable(GL_DEPTH_TEST);
			glEnable(GL_CULL_FACE);
			glCullFace(GL_BACK);
			glFrontFace(GL_CW);
			font_.flush();
		}

		return true;
	}

	void testbed::updateSettings(const time& dt)
	{
		//CHANGING DISPLAY SETTINGS 
		if (keyboard_.is_pressed(KEYCODE_I))
		{
			displayKeybinding_ = !displayKeybinding_;
		}
		if (keyboard_.is_pressed(KEYCODE_U))
		{
			displayLightSettings_ = !displayLightSettings_;
		}
		if (keyboard_.is_pressed(KEYCODE_TAB))
		{
			displayCameraSettings_ = !displayCameraSettings_;
		}
		if (keyboard_.is_pressed(KEYCODE_O))
		{
			usePostProcessEffect_ = !usePostProcessEffect_;
		}

		//CHANGING AMBIENT LIGHT SETTING
		//RED
		if (keyboard_.is_down(KEYCODE_1))
		{
			if (keyboard_.is_down(KEYCODE_LSHIFT))
			{
				ambientRed_ -= dt.as_seconds();
				if (ambientRed_ < 0.0f)
					ambientRed_ = 0.0f;
			}
			else
			{
				ambientRed_ += dt.as_seconds();
				if (ambientRed_ > 1.0f)
					ambientRed_ = 1.0f;
			}
		}
		//GREEN
		if (keyboard_.is_down(KEYCODE_2))
		{
			if (keyboard_.is_down(KEYCODE_LSHIFT))
			{
				ambientGreen_ -= dt.as_seconds();
				if (ambientGreen_ < 0.0f)
					ambientGreen_ = 0.0f;
			}
			else
			{
				ambientGreen_ += dt.as_seconds();
				if (ambientGreen_ > 1.0f)
					ambientGreen_ = 1.0f;
			}
		}
		//BLUE
		if (keyboard_.is_down(KEYCODE_3))
		{
			if (keyboard_.is_down(KEYCODE_LSHIFT))
			{
				ambientBlue_ -= dt.as_seconds();
				if (ambientBlue_ < 0.0f)
					ambientBlue_ = 0.0f;
			}
			else
			{
				ambientBlue_ += dt.as_seconds();
				if (ambientBlue_ > 1.0f)
					ambientBlue_ = 1.0f;
			}
		}

		//CHANGING DIFFUSE LIGHT SETTING
		//RED
		if (keyboard_.is_down(KEYCODE_4))
		{
			if (keyboard_.is_down(KEYCODE_LSHIFT))
			{
				diffuseRed_ -= dt.as_seconds();
				if (diffuseRed_ < 0.0f)
					diffuseRed_ = 0.0f;
			}
			else
			{
				diffuseRed_ += dt.as_seconds();
				if (diffuseRed_ > 1.0f)
					diffuseRed_ = 1.0f;
			}
		}
		//GREEN
		if (keyboard_.is_down(KEYCODE_5))
		{
			if (keyboard_.is_down(KEYCODE_LSHIFT))
			{
				diffuseGreen_ -= dt.as_seconds();
				if (diffuseGreen_ < 0.0f)
					diffuseGreen_ = 0.0f;
			}
			else
			{
				diffuseGreen_ += dt.as_seconds();
				if (diffuseGreen_ > 1.0f)
					diffuseGreen_ = 1.0f;
			}
		}
		//BLUE
		if (keyboard_.is_down(KEYCODE_6))
		{
			if (keyboard_.is_down(KEYCODE_LSHIFT))
			{
				diffuseBlue_ -= dt.as_seconds();
				if (diffuseBlue_ < 0.0f)
					diffuseBlue_ = 0.0f;
			}
			else
			{
				diffuseBlue_ += dt.as_seconds();
				if (diffuseBlue_ > 1.0f)
					diffuseBlue_ = 1.0f;
			}
		}

		//CHANGING SPECULAR LIGHT SETTING
		//RED
		if (keyboard_.is_down(KEYCODE_7))
		{
			if (keyboard_.is_down(KEYCODE_LSHIFT))
			{
				specularRed_ -= dt.as_seconds();
				if (specularRed_ < 0.0f)
					specularRed_ = 0.0f;
			}
			else
			{
				specularRed_ += dt.as_seconds();
				if (specularRed_ > 1.0f)
					specularRed_ = 1.0f;
			}
		}
		//GREEN
		if (keyboard_.is_down(KEYCODE_8))
		{
			if (keyboard_.is_down(KEYCODE_LSHIFT))
			{
				specularGreen_ -= dt.as_seconds();
				if (specularGreen_ < 0.0f)
					specularGreen_ = 0.0f;
			}
			else
			{
				specularGreen_ += dt.as_seconds();
				if (specularGreen_ > 1.0f)
					specularGreen_ = 1.0f;
			}
		}
		//BLUE
		if (keyboard_.is_down(KEYCODE_9))
		{
			if (keyboard_.is_down(KEYCODE_LSHIFT))
			{
				specularBlue_ -= dt.as_seconds();
				if (specularBlue_ < 0.0f)
					specularBlue_ = 0.0f;
			}
			else
			{
				specularBlue_ += dt.as_seconds();
				if (specularBlue_ > 1.0f)
					specularBlue_ = 1.0f;
			}
		}

		//DIRECTION X
		if (keyboard_.is_down(KEYCODE_B))
		{
			if (keyboard_.is_down(KEYCODE_LSHIFT))
			{
				xDirection_ -= dt.as_seconds();
				if (xDirection_ < -1.0f)
					xDirection_ = -1.0f;
			}
			else
			{
				xDirection_ += dt.as_seconds();
				if (xDirection_ > 1.0f)
					xDirection_ = 1.0f;
			}
		}
		//DIRECTION Y
		if (keyboard_.is_down(KEYCODE_N))
		{
			if (keyboard_.is_down(KEYCODE_LSHIFT))
			{
				yDirection_ -= dt.as_seconds();
				if (yDirection_ < -1.0f)
					yDirection_ = -1.0f;
			}
			else
			{
				yDirection_ += dt.as_seconds();
				if (yDirection_ > 0.3f)
					yDirection_ = 0.3f;
			}
		}
		//DIRECTION Z
		if (keyboard_.is_down(KEYCODE_M))
		{
			if (keyboard_.is_down(KEYCODE_LSHIFT))
			{
				zDirection_ -= dt.as_seconds();
				if (zDirection_ < -1.0f)
					zDirection_ = -1.0f;
			}
			else
			{
				zDirection_ += dt.as_seconds();
				if (zDirection_ > 1.0f)
					zDirection_ = 1.0f;
			}
		}
		//AMBIENT INTENSITY
		if (keyboard_.is_down(KEYCODE_H))
		{
			if (keyboard_.is_down(KEYCODE_LSHIFT))
			{
				ambientIntensity_ -= dt.as_seconds();
				if (ambientIntensity_ < 0.0f)
					ambientIntensity_ = 0.0f;
			}
			else
			{
				ambientIntensity_ += dt.as_seconds();
				if (ambientIntensity_ > 1.0f)
					ambientIntensity_ = 1.0f;
			}
		}
		//DIFFUSE INTENSITY
		if (keyboard_.is_down(KEYCODE_J))
		{
			if (keyboard_.is_down(KEYCODE_LSHIFT))
			{
				diffuseIntensity_ -= dt.as_seconds();
				if (diffuseIntensity_ < 0.0f)
					diffuseIntensity_ = 0.0f;
			}
			else
			{
				diffuseIntensity_ += dt.as_seconds();
				if (diffuseIntensity_ > 1.0f)
					diffuseIntensity_ = 1.0f;
			}
		}
		//SPECULAR INTENSITY
		if (keyboard_.is_down(KEYCODE_K))
		{
			if (keyboard_.is_down(KEYCODE_LSHIFT))
			{
				specularIntensity_ -= dt.as_seconds();
				if (specularIntensity_ < 0.0f)
					specularIntensity_ = 0.0f;
			}
			else
			{
				specularIntensity_ += dt.as_seconds();
				if (specularIntensity_ > 1.0f)
					specularIntensity_ = 1.0f;
			}
		}

		directionallight_.changeAmbientColor(glm::vec3(ambientRed_, ambientGreen_, ambientBlue_));
		directionallight_.changeDiffuseColor(glm::vec3(diffuseRed_, diffuseGreen_, diffuseBlue_));
		directionallight_.changeSpecularColor(glm::vec3(specularRed_, specularGreen_, specularBlue_));
		directionallight_.changeAmbientIntenstity(ambientIntensity_);
		directionallight_.changeDiffuseIntenstity(diffuseIntensity_);
		directionallight_.changeSpecularIntenstity(specularIntensity_);
		directionallight_.changeDirection(glm::vec3(xDirection_, yDirection_, zDirection_));

		pointlight_.changeAmbientColor(glm::vec3(ambientRed_, ambientGreen_, ambientBlue_));
		pointlight_.changeDiffuseColor(glm::vec3(diffuseRed_, diffuseGreen_, diffuseBlue_));
		pointlight_.changeSpecularColor(glm::vec3(specularRed_, specularGreen_, specularBlue_));
		pointlight_.changeAmbientIntenstity(ambientIntensity_);
		pointlight_.changeDiffuseIntenstity(diffuseIntensity_);
		pointlight_.changeSpecularIntenstity(specularIntensity_);
	}

	void testbed::updateCameraText(const time& dt, fps_camera& camera)
	{
		////DISPLAY FPS
		string text = "FPS: " + std::to_string((1.0f / dt.as_seconds()));
		font_.render(2.0f, 2.0f, text);
		text = "dt: " + std::to_string(dt.as_seconds());
		font_.render(2.0f, 12.0f, text);
		//DISPLAY CAMERA INFORMATION
		text = "roll: " + std::to_string(camera_.roll_);
		font_.render(152.0f, 2.0f, text);
		text = "pitch: " + std::to_string(camera_.pitch_);
		font_.render(152.0f, 12.0f, text);
		text = "yaw: " + std::to_string(camera_.yaw_);
		font_.render(152.0f, 22.0f, text);
		text = "x: " + std::to_string(camera_.position_.x);
		font_.render(300.0f, 2.0f, text);
		text = "y: " + std::to_string(camera_.position_.y);
		font_.render(300.0f, 12.0f, text);
		text = "z: " + std::to_string(camera_.position_.z);
		font_.render(300.0f, 22.0f, text);
	}

	void testbed::updateLightText()
	{
		float xPos = 1000.0f;
		float ambientOffset = 0.0f;
		string text = "AMBIENT COLOR";
		font_.render(xPos, 12.0f + ambientOffset, text);
		text = "R:" + std::to_string(ambientRed_) + " G:" + std::to_string(ambientGreen_) + " B:" + std::to_string(ambientBlue_);
		font_.render(xPos, 24.0f + ambientOffset, text);
		text = "Intensity: " + std::to_string(ambientIntensity_);
		font_.render(xPos, 36 + ambientOffset, text);

		float diffuseOffset = 50.0f;
		text = "DIFFUSE COLOR";
		font_.render(xPos, 12.0f + diffuseOffset, text);
		text = "R:" + std::to_string(diffuseRed_) + " G:" + std::to_string(diffuseGreen_) + " B:" + std::to_string(diffuseBlue_);
		font_.render(xPos, 24.0f + diffuseOffset, text);
		text = "Intensity: " + std::to_string(diffuseIntensity_);
		font_.render(xPos, 36.0f + diffuseOffset, text);

		float specularOffset = 100.0f;
		text = "SPECULAR COLOR";
		font_.render(xPos, 12.0f + specularOffset, text);
		text = "R:" + std::to_string(specularRed_) + " G:" + std::to_string(specularGreen_) + " B:" + std::to_string(specularBlue_);
		font_.render(xPos, 24.0f + specularOffset, text);
		text = "Intensity: " + std::to_string(specularIntensity_);
		font_.render(xPos, 36 + specularOffset, text);

		float directionOffset = 150.0f;
		text = "DIRECTION";
		font_.render(xPos, 12.0f + directionOffset, text);
		text = "X:" + std::to_string(directionallight_.direction_.x) + " Y:" 
			+ std::to_string(directionallight_.direction_.y) + " Z:" + std::to_string(directionallight_.direction_.z);
		font_.render(xPos, 24.0f + directionOffset, text);
	}

	void testbed::updateKeybindingText()
	{
		if (!displayKeybinding_)
		{
			string text = "I - Show keybindings";
			font_.render(2.0f, 50.0f, text);
			text = "O - toggle post processing effect (invert color)";
			font_.render(2.0f, 70.0f, text);
		}
		else
		{
			string text = "I - Hide keybindings";
			font_.render(2.0f, 50.0f, text);
			text = "TAB - toggle camera setting display";
			font_.render(2.0f, 70.0f, text);
			text = "U - toggle light setting display";
			font_.render(2.0f, 90.0f, text);
			text = "O - toggle post processing effect (invert color)";
			font_.render(2.0f, 110.0f, text);

			float movementOffset = 70.0f;
			text = "MOVEMENT";
			font_.render(2.0f, 70.0f + movementOffset, text);
			text = "W,A,S,D";
			font_.render(2.0f, 90.0f + movementOffset, text);
			text = "SPACE - increase altitude";
			font_.render(2.0f, 110.0f + movementOffset, text);
			text = "L_CTRL - decrease altitude";
			font_.render(2.0f, 130.0f + movementOffset, text);

			float lightOffset = 170.0f;
			text = "DIRECTIONAL LIGHT";
			font_.render(2.0f, 70.0f + lightOffset, text);
			text = "HOLD SHIFT TO DECREASE VALUES";
			font_.render(2.0f, 90.0f + lightOffset, text);
			text = "1,2,3 - Modify ambient color";
			font_.render(2.0f, 110.0f + lightOffset, text);
			text = "4,5,6 - Modify diffuse color";
			font_.render(2.0f, 130.0f + lightOffset, text);
			text = "7,8,9 - Modify specular color";
			font_.render(2.0f, 150.0f + lightOffset, text);
			text = "H,J,K - Modify color intensity ( ambient, diffuse, specular )";
			font_.render(2.0f, 170.0f + lightOffset, text);
			text = "B,N,M - Modify directional light direction ( X, Y, Z )";
			font_.render(2.0f, 190.0f + lightOffset, text);
		}

	}

	void testbed::updateObjectTransforms(const time& dt)
	{
		orbit_ += 0.02f;
		if (orbit_ > 2.0f * 3.141592f)
		{
			orbit_ -= 2.0f * 3.141592f;
		}

		cube_.translate(glm::mat4(1.0f), glm::vec3(glm::cos(orbit_) * 2.0f, 3.0f, glm::sin(orbit_) * 1.4f));
		cube2_.translate(glm::mat4(1.0f), glm::vec3(6.0f, 3.2f, -4.7f));
		cube2_.rotate(cube2_.world, orbit_, glm::vec3(0.0f, 1.0f, 1.0f));
		sphereDL_.translate(cube_.world,glm::vec3(-5.0f + glm::cos(orbit_), 0.5f, 2.5f));
		sphereDL_.rotate(sphereDL_.world, orbit_, glm::vec3(0.0f, 0.0f, 1.0f));
		sphereDL2_.translate(glm::mat4(1.0f), glm::vec3(4.7f, glm::sin(orbit_) + 6.0f, 5.0f));


		pointlight_.translate(pointlight_.world, glm::vec3(0.01f, 0.0f, 0.0f));
		sphere_.translate(pointlight_.world, glm::vec3(5.0f * cosf(orbit_), 2.0f * sinf(orbit_ * 2.0f), 5.0f * sinf(orbit_)));
		sphere_.rotate(sphere_.world, orbit_, glm::vec3(1.0f, 1.0f, 1.0f));
		sphere2_.translate(glm::mat4(1.0f), glm::vec3(30.0f, 2.0f * sinf(orbit_ * 2.0f), -6.5f));
	}

} // !neon
