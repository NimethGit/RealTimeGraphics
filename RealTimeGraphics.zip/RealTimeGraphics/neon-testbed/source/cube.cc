#include "cube.h"
//Cube.cc

neon::cube::cube()
{
	world = glm::mat4(1.0f);

	dynamic_array<vertex> vertices;
	dynamic_array<uint32> indices;
	//FRONT
	float r = scale_;
	vertex FrontTL = { glm::vec3( -r ,  r , r), glm::vec2(0.0f,0.0f), glm::vec3(0.0f,0.0f,1.0f) };		  //0
	vertex FrontTR = { glm::vec3(  r ,  r , r), glm::vec2(1.0f,0.0f), glm::vec3(0.0f,0.0f,1.0f) };		  //1
	vertex FrontBR = { glm::vec3(  r , -r , r), glm::vec2(1.0f,1.0f), glm::vec3(0.0f,0.0f,1.0f) };		  //2
	vertex FrontBL = { glm::vec3( -r , -r , r), glm::vec2(0.0f,1.0f), glm::vec3(0.0f,0.0f,1.0f) };		  //3
	//BACK																								  
	vertex BackTL = { glm::vec3(r ,  r , -r), glm::vec2(0.0f,0.0f), glm::vec3(0.0f,0.0f,-1.0f) };		  //4
	vertex BackTR = { glm::vec3(-r ,  r , -r), glm::vec2(1.0f,0.0f), glm::vec3(0.0f,0.0f,-1.0f) };		  //5
	vertex BackBR = { glm::vec3(-r , -r , -r), glm::vec2(1.0f,1.0f), glm::vec3(0.0f,0.0f,-1.0f) };		  //6
	vertex BackBL = { glm::vec3(r , -r , -r), glm::vec2(0.0f,1.0f), glm::vec3(0.0f,0.0f,-1.0f) };		  //7
	//TOP																								  
	vertex TopTL = { glm::vec3(-r ,  r , -r), glm::vec2(0.0f,0.0f), glm::vec3(0.0f,1.0f,0.0f) };		  //8
	vertex TopTR = { glm::vec3(r ,  r , -r), glm::vec2(1.0f,0.0f), glm::vec3(0.0f,1.0f,0.0f) };			  //9
	vertex TopBR = { glm::vec3(r ,  r , r), glm::vec2(1.0f,1.0f), glm::vec3(0.0f,1.0f,0.0f) };			  //10
	vertex TopBL = { glm::vec3(-r ,  r , r), glm::vec2(0.0f,1.0f), glm::vec3(0.0f,1.0f,0.0f) };			  //11
	//BOTTOM																							  
	vertex BotTL = { glm::vec3(-r , -r , r), glm::vec2(0.0f,0.0f), glm::vec3(0.0f,-1.0f,0.0f) };		  //12
	vertex BotTR = { glm::vec3(r , -r , r), glm::vec2(1.0f,0.0f), glm::vec3(0.0f,-1.0f,0.0f) };			  //13
	vertex BotBR = { glm::vec3(r , -r , -r), glm::vec2(1.0f,1.0f), glm::vec3(0.0f,-1.0f,0.0f) };		  //14
	vertex BotBL = { glm::vec3(-r , -r , -r), glm::vec2(0.0f,1.0f), glm::vec3(0.0f,-1.0f,0.0f) };		  //15
	//RIGHT
	vertex RightTL = { glm::vec3(r,r,r), glm::vec2(0.0f,0.0f), glm::vec3(1.0f,0.0f,0.0f) };				  //16
	vertex RightTR = { glm::vec3(r,r,-r), glm::vec2(1.0f,0.0f), glm::vec3(1.0f,0.0f,0.0f) };			  //17
	vertex RightBR = { glm::vec3(r,-r,-r), glm::vec2(1.0f,1.0f), glm::vec3(1.0f,0.0f,0.0f) };			  //18
	vertex RightBL = { glm::vec3(r,-r,r), glm::vec2(0.0f,1.0f), glm::vec3(1.0f,0.0f,0.0f) };			  //19
	//LEFT
	vertex LeftTL = { glm::vec3(-r ,  r , -r), glm::vec2(0.0f,0.0f), glm::vec3(-1.0f,0.0f,0.0f) };		  //20
	vertex LeftTR = { glm::vec3(-r ,  r , r), glm::vec2(1.0f,0.0f), glm::vec3(-1.0f,0.0f,0.0f) };		  //21
	vertex LeftBR = { glm::vec3(-r , -r , r), glm::vec2(1.0f,1.0f), glm::vec3(-1.0f,0.0f,0.0f) };		  //22
	vertex LeftBL = { glm::vec3(-r , -r , -r), glm::vec2(0.0f,1.0f), glm::vec3(-1.0f,0.0f,0.0f) };		  //23

	vertices.push_back(FrontTL);
	vertices.push_back(FrontTR);
	vertices.push_back(FrontBR);
	vertices.push_back(FrontBL);
	vertices.push_back(BackTL);
	vertices.push_back(BackTR);
	vertices.push_back(BackBR);
	vertices.push_back(BackBL);
	vertices.push_back(TopTL);
	vertices.push_back(TopTR);
	vertices.push_back(TopBR);
	vertices.push_back(TopBL);
	vertices.push_back(BotTL);
	vertices.push_back(BotTR);
	vertices.push_back(BotBR);
	vertices.push_back(BotBL);
	vertices.push_back(RightTL);
	vertices.push_back(RightTR);
	vertices.push_back(RightBR);
	vertices.push_back(RightBL);
	vertices.push_back(LeftTL);
	vertices.push_back(LeftTR);
	vertices.push_back(LeftBR);
	vertices.push_back(LeftBL);


	int index = 0;
	for (int i = 0; i < 6; i++)
	{
		int startIndex = index;
		//TOP
		indices.push_back(index);
		index++; 
		indices.push_back(index);
		index++;
		indices.push_back(index);
		//BOTTOM
		indices.push_back(index);
		index++;
		indices.push_back(index);
		index++;
		indices.push_back(startIndex);
	}

	index_count_ = (int)indices.size();

	if (!ibo_.create(index_count_ * sizeof(uint32), GL_UNSIGNED_INT, indices.data()))
	{
		return;
	}

	if (!vbo_.create(sizeof(vertex) * (int)vertices.size(), vertices.data()))
	{
		return;
	}

	if (!program_.create("assets/shadow/shadow_vertex_shader.txt", "assets/shadow/shadow_fragment_shader.txt"))
	{
		return;
	}

	if (!program_depth_.create("assets/shadow/DepthMapGeneration_vertex_shader.txt", "assets/shadow/DepthMapGeneration_fragment_shader.txt"))
	{
		return;
	}

	format_.add_attribute(0, 3, GL_FLOAT, false);
	format_.add_attribute(1, 2, GL_FLOAT, false);
	format_.add_attribute(2, 3, GL_FLOAT, false);

	if (!texture_.create("assets/cube/cube.png"))
	{
		return;
	}

	if (!sampler_.create(GL_NEAREST, GL_CLAMP_TO_EDGE, GL_CLAMP_TO_EDGE))
	{
		return;
	}
}

void neon::cube::render(glm::mat4 projectionMatrix, glm::mat4 viewMatrix, glm::vec3 cameraPosition, directionallight &dl, glm::mat4 lightMVP)
{
	program_.bind();

	program_.set_uniform_texture("diffuse", 0);
	program_.set_uniform_texture("depth_map", 1);

	program_.set_uniform_mat4("projection", projectionMatrix);
	program_.set_uniform_mat4("view", viewMatrix);
	program_.set_uniform_mat4("world", world);
	program_.set_uniform_mat4("lightMVP", lightMVP);

	program_.set_uniform_vec3("ambient_light_color", dl.ambient_color_);
	program_.set_uniform_vec3("diffuse_light_color", dl.diffuse_color_);
	program_.set_uniform_vec3("specular_light_color", dl.specular_color_);
	program_.set_uniform_float("ambient_intensity", dl.ambient_intensity_);
	program_.set_uniform_float("diffuse_intensity", dl.diffuse_intensity_);
	program_.set_uniform_float("specular_intensity", dl.specular_intensity_);

	program_.set_uniform_vec3("light_direction", dl.direction_);
	program_.set_uniform_vec3("camera_pos", cameraPosition);

	vbo_.bind();
	format_.bind();
	ibo_.bind();

	texture_.bind(0);
	sampler_.bind(0); //Binding this sampler to the unit 0
	sampler_.bind(1); 

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);
	glCullFace(GL_BACK);
	glFrontFace(GL_CW);
	ibo_.render(GL_TRIANGLES, 0, index_count_);
}

void neon::cube::renderDepth(glm::mat4 lightMVP)
{
	program_depth_.bind();
	program_depth_.set_uniform_mat4("lightMVP", lightMVP);
	program_depth_.set_uniform_mat4("world", world);

	vbo_.bind();
	format_.bind();
	ibo_.bind();

	//texture_.bind();	//NOT SURE IF WE NEED TO BIND THE TEXTURE OR SAMPLER HERE
	//sampler_.bind();

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);
	//glCullFace(GL_FRONT);	//ADDED
	glCullFace(GL_BACK); //COMMENTED OUT
	glFrontFace(GL_CW);
	ibo_.render(GL_TRIANGLES, 0, index_count_);
	//glCullFace(GL_BACK); //ADDED

}

void neon::cube::setPosition(glm::vec3 newPosition)
{
	world[3][0] = newPosition.x;
	world[3][1] = newPosition.y;
	world[3][2] = newPosition.z;
}

void neon::cube::translate(glm::mat4 startingPoint, glm::vec3 translation)
{
	world = glm::translate(startingPoint, translation);
}

void neon::cube::rotate(glm::mat4 origin, float rotationAmount, glm::vec3 axis)
{
	world = glm::rotate(origin, rotationAmount, axis);
}

