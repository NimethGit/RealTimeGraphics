#include "pointlight.h"

neon::pointlight::pointlight()
{
	position_ = glm::vec3(0.0f, 0.0f, 0.0f);
	world = glm::mat4(1.0f);
	ambient_color_ = glm::vec3(1.0f, 1.0f, 0.0f);
	diffuse_color_ = glm::vec3(1.0f, 1.0f, 0.0f);
	specular_color_ = glm::vec3(1.0f, 1.0f, 0.0f);
	ambient_intensity_ = 0.3f;
	diffuse_intensity_ = 0.3f;
	specular_intensity_ = 0.3f;

	dynamic_array<vertex> vertices;
	dynamic_array<uint32> indices;
	//FRONT
	float r = radius_;
	vertex FrontTL = { glm::vec3(-r ,  r , r), glm::vec2(0.0f,0.0f)};		  //0
	vertex FrontTR = { glm::vec3(r ,  r , r), glm::vec2(1.0f,0.0f)};		  //1
	vertex FrontBR = { glm::vec3(r , -r , r), glm::vec2(1.0f,1.0f)};		  //2
	vertex FrontBL = { glm::vec3(-r , -r , r), glm::vec2(0.0f,1.0f)};		  //3
	//BACK																								  
	vertex BackTL = { glm::vec3(r ,  r , -r), glm::vec2(0.0f,0.0f)};		  //4
	vertex BackTR = { glm::vec3(-r ,  r , -r), glm::vec2(1.0f,0.0f)};		  //5
	vertex BackBR = { glm::vec3(-r , -r , -r), glm::vec2(1.0f,1.0f)};		  //6
	vertex BackBL = { glm::vec3(r , -r , -r), glm::vec2(0.0f,1.0f)};		  //7
	//TOP																								  
	vertex TopTL = { glm::vec3(-r ,  r , -r), glm::vec2(0.0f,0.0f)};		  //8
	vertex TopTR = { glm::vec3(r ,  r , -r), glm::vec2(1.0f,0.0f)};			  //9
	vertex TopBR = { glm::vec3(r ,  r , r), glm::vec2(1.0f,1.0f)};			  //10
	vertex TopBL = { glm::vec3(-r ,  r , r), glm::vec2(0.0f,1.0f)};			  //11
	//BOTTOM																							  
	vertex BotTL = { glm::vec3(-r , -r , r), glm::vec2(0.0f,0.0f)};			  //12
	vertex BotTR = { glm::vec3(r , -r , r), glm::vec2(1.0f,0.0f)};			  //13
	vertex BotBR = { glm::vec3(r , -r , -r), glm::vec2(1.0f,1.0f)};			  //14
	vertex BotBL = { glm::vec3(-r , -r , -r), glm::vec2(0.0f,1.0f)};		  //15
	//RIGHT
	vertex RightTL = { glm::vec3(r,r,r), glm::vec2(0.0f,0.0f)};				  //16
	vertex RightTR = { glm::vec3(r,r,-r), glm::vec2(1.0f,0.0f)};			  //17
	vertex RightBR = { glm::vec3(r,-r,-r), glm::vec2(1.0f,1.0f)};			  //18
	vertex RightBL = { glm::vec3(r,-r,r), glm::vec2(0.0f,1.0f)};			  //19
	//LEFT
	vertex LeftTL = { glm::vec3(-r ,  r , -r), glm::vec2(0.0f,0.0f)};		  //20
	vertex LeftTR = { glm::vec3(-r ,  r , r), glm::vec2(1.0f,0.0f)};		  //21
	vertex LeftBR = { glm::vec3(-r , -r , r), glm::vec2(1.0f,1.0f)};		  //22
	vertex LeftBL = { glm::vec3(-r , -r , -r), glm::vec2(0.0f,1.0f)};		  //23

	vertices.push_back(FrontTL);
	vertices.push_back(FrontTR);
	vertices.push_back(FrontBR);
	vertices.push_back(FrontBL);
	vertices.push_back(BackTL);
	vertices.push_back(BackTR);
	vertices.push_back(BackBR);
	vertices.push_back(BackBL);
	vertices.push_back(TopTL);
	vertices.push_back(TopTR);
	vertices.push_back(TopBR);
	vertices.push_back(TopBL);
	vertices.push_back(BotTL);
	vertices.push_back(BotTR);
	vertices.push_back(BotBR);
	vertices.push_back(BotBL);
	vertices.push_back(RightTL);
	vertices.push_back(RightTR);
	vertices.push_back(RightBR);
	vertices.push_back(RightBL);
	vertices.push_back(LeftTL);
	vertices.push_back(LeftTR);
	vertices.push_back(LeftBR);
	vertices.push_back(LeftBL);


	int index = 0;
	for (int i = 0; i < 6; i++)
	{
		int startIndex = index;
		//TOP
		indices.push_back(index);
		index++;
		indices.push_back(index);
		index++;
		indices.push_back(index);
		//BOTTOM
		indices.push_back(index);
		index++;
		indices.push_back(index);
		index++;
		indices.push_back(startIndex);
	}
	index_count_ = (int)indices.size();

	if (!ibo_.create(index_count_ * sizeof(uint32), GL_UNSIGNED_INT, indices.data()))
	{
		return;
	}

	if (!vbo_.create(sizeof(vertex) * (int)vertices.size(), vertices.data()))
	{
		return;
	}

	if (!program_.create("assets/pointlight/pointlight_vertex_shader.txt", "assets/pointlight/pointlight_fragment_shader.txt"))
	{
		return;
	}

	format_.add_attribute(0, 3, GL_FLOAT, false);
	format_.add_attribute(1, 2, GL_FLOAT, true);

	if (!texture_.create("assets/pointlight/pointlight.png"))
	{
		return;
	}

	if (!sampler_.create(GL_NEAREST, GL_CLAMP_TO_EDGE, GL_CLAMP_TO_EDGE))
	{
		return;
	}
}

void neon::pointlight::render(glm::mat4 projectionMatrix, glm::mat4 viewMatrix)
{
	program_.bind();
	program_.set_uniform_mat4("projection", projectionMatrix);
	program_.set_uniform_mat4("view", viewMatrix);
	program_.set_uniform_mat4("world", world);

	program_.set_uniform_vec3("ambient_light_color", ambient_color_);

	vbo_.bind();
	format_.bind();
	ibo_.bind();

	texture_.bind();
	sampler_.bind();

	glEnable(GL_DEPTH_TEST);
	glEnable(GL_CULL_FACE);
	glCullFace(GL_BACK);
	glFrontFace(GL_CW);
	ibo_.render(GL_TRIANGLES, 0, index_count_);
}


void neon::pointlight::setPosition(glm::vec3 newPosition)
{
	world[3][0] = newPosition.x;
	world[3][1] = newPosition.y;
	world[3][2] = newPosition.z;
}

void neon::pointlight::translate(glm::mat4 startingPoint, glm::vec3 translation)
{
	world = glm::translate(startingPoint, translation);
	position_.x = world[3][0];
	position_.y = world[3][1];
	position_.z = world[3][2];
}

void neon::pointlight::rotate(glm::mat4 origin, float rotationAmount, glm::vec3 axis)
{
	world = glm::rotate(origin, rotationAmount, axis);
	position_.x = world[3][0];
	position_.y = world[3][1];
	position_.z = world[3][2];
}

void neon::pointlight::changeAttenuation(float constant, float linear, float quadratic)
{
	constant_ = constant;
	linear_ = linear;
	quadratic_ = quadratic;
}

void neon::pointlight::changeAmbientColor(glm::vec3 newColor)
{
	ambient_color_ = newColor; 
}

void neon::pointlight::changeDiffuseColor(glm::vec3 newColor)
{
	diffuse_color_ = newColor;
}

void neon::pointlight::changeSpecularColor(glm::vec3 newColor)
{
	specular_color_ = newColor;
}

void neon::pointlight::changeAmbientIntenstity(float newIntensity)
{
	ambient_intensity_ = newIntensity;
}

void neon::pointlight::changeDiffuseIntenstity(float newIntensity)
{
	diffuse_intensity_ = newIntensity;
}

void neon::pointlight::changeSpecularIntenstity(float newIntensity)
{
	specular_intensity_ = newIntensity;
}
