#include "directionallight.h"

neon::directionallight::directionallight()
{
	direction_ = glm::normalize(glm::vec3(0.0f, -1.0f, 0.0f));
	ambient_color_ = glm::vec3(0.4f, 0.4f, 0.0f);
	diffuse_color_ = glm::vec3(0.2f, 0.2f, 0.2f);
	specular_color_ = glm::vec3(0.1f, 0.1f, 0.1f);

	ambient_intensity_ = 0.8f;
	diffuse_intensity_ = 0.4f;
	specular_intensity_ = 0.5f;
}

void neon::directionallight::changeAmbientColor(glm::vec3 newColor)
{
	ambient_color_ = newColor;
}

void neon::directionallight::changeDiffuseColor(glm::vec3 newColor)
{
	diffuse_color_ = newColor;
}

void neon::directionallight::changeSpecularColor(glm::vec3 newColor)
{
	specular_color_ = newColor;
}

void neon::directionallight::changeAmbientIntenstity(float newIntensity)
{
	ambient_intensity_ = newIntensity;
}

void neon::directionallight::changeDiffuseIntenstity(float newIntensity)
{
	diffuse_intensity_ = newIntensity;
}

void neon::directionallight::changeSpecularIntenstity(float newIntensity)
{
	specular_intensity_ = newIntensity;
}

void neon::directionallight::changeDirection(glm::vec3 newDirection)
{
	direction_ = glm::normalize(newDirection);
}
