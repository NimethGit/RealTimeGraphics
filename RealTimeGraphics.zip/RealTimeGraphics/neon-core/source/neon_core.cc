// neon_core.cc

#include "neon_core.h"

namespace neon {

} // !neon
