This project was created for the course "Real-time Graphics Programming for Games 1" Course code (5sd805) by Miguel Redondo. This is the second assignment of the course.

The objective of the assignment was to create a scene with objects being lit up by a directional light. 
It was required that we had at least four objects that were textured and affected by the directional light. The objects had to be constantly moving or rotating.
It was also required that you could modify the directional light's color and direction.
There were also specifics about having a dynamic FPS counter as well as a moveable camera, basically just simulating a real game engine without the physics part.

Something that I added even though it was not required was two spheres and a point light which can be seen in the far back of the starting screen. 
The pointlight-spheres do cast shadows(from the directional light) but they are not affected by other objects' shadow. 
This is something that I intend to change later on because I want them be affected by both the directional light and the point light.

I also applied shadow mapping to the scene as well as a post processing effect.

The way one modifies the light direction and color is through hardcoded keybindings. The keybindings can be shown "in-game" by pressing the 'I' key.
The required FPS counter can be toggled on/off by pressing the 'TAB' key.
The post processing effect/filter can be toggled on/off by pressing the 'O' key.

IN ORDER TO RUN THE PROGRAM
1. Build the program
2. Add the "assimp-vc142-mtd.dll" file (found at neon-testbed -> external -> assimp -> bin) to the build file. 
3. Make TESTBED as start-up project.
 

